import EventsMongo from './EventsMongo';

export { EventsMongo };
