import GameMongo from './GameMongo';

export default GameMongo;
