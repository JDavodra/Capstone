import JournalMongo from './JournalMongo';

export default JournalMongo;
