import { Request, Response } from 'express';

import keys from '../../../config/authentication/keys';
import { UserModel, GameModel } from '../../models/';

const bcrypt = require('bcryptjs');
const jwt = require("jsonwebtoken");
// Get user from database
const getUser = (req: Request, res: Response) => {
    try {
        // gets the user value for a specific user, receive the user id in argument
        UserModel.findOne({ "_id": req.params.userid }).then((user: any) => {
            if (!user) {
                const error = { points: "Error getting user" };
                return res.status(404).json(error);
            }
            else if (user) {
                // returning the values found
                const payload = {
                    id: user._id,
                    name: user.name,
                    phoneNumber: user.phoneNumber,
                    email: user.email,
                    dateOfBirth: user.dateOfBirth,
                    gender: user.gender,
                    avatar: user.avatar
                };
                res.status(200).json(payload);
            }
            else { res.status(404).json({ output: "not found" }); }
        });
    }
    catch (error: any) {
        res.status(400).json({ errorResponse: error, userID: req.params.userid });
    }
};
// Get all users in database
const getAllUsers = (req: Request, res: Response) => {
    try {
        UserModel.find({}, (err: any, UserList: Document[]) => {
            if (err) { throw err; }
            else if (UserList && UserList.length !== 0) { res.status(200).json({ UserList }); } // Get and store as list
            else { res.status(404).json({ output: "not found" }); }
        });
    }
    catch (error: any) {
        res.status(400).json({ errorResponse: error });
    }
};
// Signup user
const register = (req: Request, res: Response) => {
    // Form validation
    try {
        // Check if user already exists by checking for existing email in database
        UserModel.findOne({ "email": req.body.email }).then((user: any) => {
            if (user) {
                const error = { user: "User (email) already exists" };
                return res.status(400).json(error);
            } else {
                // If user is new add to database
                const newUser: any = new UserModel({
                    name: {
                        firstName: req.body.firstName,
                        lastName: req.body.lastName
                    },
                    phoneNumber: req.body.phoneNumber,
                    email: req.body.email,
                    password: req.body.password, // Add as plain text first, hash later
                    dateOfBirth: req.body.dateOfBirth,
                    gender: req.body.gender
                });
                // Hash password before saving in database
                bcrypt.genSalt(10, (e, salt) => {
                    bcrypt.hash(newUser.password, salt, (err, hash) => {
                        newUser.password = hash; // Save hashed password
                        newUser
                            .save()
                            .then((new_user) => {
                                // Create a gamification model and reference user id to connect the two documents
                                const userGameRecord = new GameModel({
                                    userId: newUser._id,
                                    lastLoginDate: new Date()
                                });
                                userGameRecord
                                    .save()
                                    .then(res.json(new_user))
                                    .catch(e_catch => console.log(e_catch));
                            }
                            )
                            .catch(e_catch => console.log(e_catch));
                    });
                });
            }
        });
    } catch (err: any) {
        res.status(503).json('Service Unavailable');
        console.log(err.stack);
    }
};
// Signin User
const login = (req: Request, res: Response) => {
    // Form validation
    try {
        const { email, password } = req.body;
        // Find staff by id
        UserModel.findOne({ 'email': email }).then((user: any) => {
            // Check if staff exists
            if (!user) {
                const error = { password: "Email Invalid" }; // Provide error
                return res.status(404).json(error);
            }
            // Check password
            bcrypt.compare(password, user.password).then(isMatch => {
                if (isMatch) {
                    // Staff matched
                    // Create JWT Payload
                    const payload = {
                        id: user._id,
                        name: user.name,
                        phoneNumber: user.phoneNumber,
                        email: user.email,
                        dateOfBirth: user.dateOfBirth,
                        gender: user.gender,
                        avatar: user.avatar
                    };
                    // Sign token
                    jwt.sign(
                        payload,
                        keys.secretOrKey,
                        { expiresIn: 31556926 }, // 1 year in seconds
                        (err, token) => {
                            res.json({ success: true, token: "Bearer " + token });
                        }
                    );
                } else {
                    // Incorrect password
                    return res.status(400).json({ password: "Password Incorrect" });
                }
            });
        });
    } catch (err) {
        res.status(503).json('Service Unavailable');
        console.error('Database Connection Error', err.stack);
    }
};
// Update user info
const updateUser = (req: Request, res: Response) => {
    try {
        // Get all info and update all fields simultaneously even if there is no change
        const update = {
            name: req.body.name,
            phoneNumber: req.body.phoneNumber,
            email: req.body.email,
            dateOfBirth: req.body.dateOfBirth,
            gender: req.body.gender,
            avatar: req.body.avatar
        }
        // Find user id and update info
        UserModel.findByIdAndUpdate(req.params.userid, update)
            .then((user: any) => {
                const payload = {
                    id: user._id,
                    name: user.name,
                    phoneNumber: user.phoneNumber,
                    email: user.email,
                    dateOfBirth: user.dateOfBirth,
                    gender: user.gender,
                    avatar: user.avatar
                };
                res.status(200).json(payload);
            })
            .catch(err => res.status(400).json({ error: "Improper game ID or data" })) // This means there is an error in the code so this should not occur
    }
    catch (error: any) {
        res.status(400).json({ errorResponse: error, userID: req.params.gameid }); // Error in code or database
    }
}

const UserMongo = {
    getUser,
    getAllUsers,
    register,
    login,
    updateUser
};

export default UserMongo;
