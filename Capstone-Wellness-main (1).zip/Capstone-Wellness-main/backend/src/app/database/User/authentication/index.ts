import validateLoginInput from './login';

export default validateLoginInput;
