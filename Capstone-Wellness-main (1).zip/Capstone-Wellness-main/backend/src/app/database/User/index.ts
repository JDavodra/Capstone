import UserMongo from './UserMongo';

export default UserMongo;
