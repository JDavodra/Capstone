import WellnessTipMongo from './WellnessTipMongo';

export {WellnessTipMongo};
