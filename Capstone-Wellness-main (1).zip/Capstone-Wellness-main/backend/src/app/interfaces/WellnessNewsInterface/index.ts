import IWellnessNews from './WellnessNewsInterface';
import { convertToWellnessNews, convertWellnessNewsToJSON} from './WellnessNewsConverter';

export { IWellnessNews, convertToWellnessNews, convertWellnessNewsToJSON};
