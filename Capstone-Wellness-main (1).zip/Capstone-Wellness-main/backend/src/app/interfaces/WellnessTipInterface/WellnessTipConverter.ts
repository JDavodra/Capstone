import IWellnessTip from './WellnessTipInterface';
// Convert to wellness tip format
const convertToWellnessTipSmartsheet = (cells:any[]) =>{
  const converted:IWellnessTip = {
    date:cells[1].value,
    specialDay:cells[2].value,
    tipOfTheDay:cells[3].value,
    source:cells[4].value
  };
  return converted;
};

export {
  convertToWellnessTipSmartsheet,
};
