// Wellness tip format
interface IWellnessTip {
  specialDay:string
  source:string
  tipOfTheDay:string
  date:string
};

export default IWellnessTip;
