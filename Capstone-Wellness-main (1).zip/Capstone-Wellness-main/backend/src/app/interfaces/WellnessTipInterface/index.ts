import { convertToWellnessTipSmartsheet } from './WellnessTipConverter';
import IWellnessTip from './WellnessTipInterface';

export {IWellnessTip,convertToWellnessTipSmartsheet};
