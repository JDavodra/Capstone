import ActivitiesBookings from "./ActivitiesBookings";

export { ActivitiesBookings };
