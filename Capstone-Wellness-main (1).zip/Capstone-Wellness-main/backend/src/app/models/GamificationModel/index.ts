import GameModel from './GameModel';

export default GameModel;
