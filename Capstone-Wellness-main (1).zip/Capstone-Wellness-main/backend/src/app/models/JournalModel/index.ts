import JournalModel from './JournalModel';

export default JournalModel;
