import UserModel from './UserModel';

export default UserModel;
