import WellnessTipModel from './WellnessTip';

export { WellnessTipModel };
