import ActivitiesBookingsRouter from './ActivitiesBookingsRouter';

export {ActivitiesBookingsRouter};
