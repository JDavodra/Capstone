import EventsRouter from './EventsRouter';

export {EventsRouter};
