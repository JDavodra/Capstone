import GameRouter from './GameRouter';

export default GameRouter;