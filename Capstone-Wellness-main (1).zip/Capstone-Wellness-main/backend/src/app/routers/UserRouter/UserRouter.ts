import { Router } from 'express';

import { UserService } from '../../services';

const UserRouter = Router();
const user = new UserService();

// POST Login
UserRouter.post('/login', user.login());
// POST Register
UserRouter.post('/register', user.register());
// PATCH User
UserRouter.patch('/update-user/:userid', user.updateUser());
// GET All Users
UserRouter.get('/get-all-users', user.getAllUsers());
// GET a user
UserRouter.get('/get-user/:userid', user.getUser());

export default UserRouter;
