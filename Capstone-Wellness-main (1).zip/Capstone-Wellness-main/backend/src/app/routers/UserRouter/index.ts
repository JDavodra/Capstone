import UserRouter from './UserRouter';

export default UserRouter;
