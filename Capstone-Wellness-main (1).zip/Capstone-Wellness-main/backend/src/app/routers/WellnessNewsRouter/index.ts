import WellnessNewsRouter from './WellnessNewsRouter';

export {WellnessNewsRouter};
