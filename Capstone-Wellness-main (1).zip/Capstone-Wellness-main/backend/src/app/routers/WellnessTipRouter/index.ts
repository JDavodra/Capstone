import WellnessTipRouter from './WellnessTipRouter';

export {WellnessTipRouter};
