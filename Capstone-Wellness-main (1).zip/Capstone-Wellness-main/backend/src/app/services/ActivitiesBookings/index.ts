import ActivitiesBookingsService from './ActivitiesBookingsService';

export { ActivitiesBookingsService };
