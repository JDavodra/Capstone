import EventsService from './EventsService';

export {EventsService};
