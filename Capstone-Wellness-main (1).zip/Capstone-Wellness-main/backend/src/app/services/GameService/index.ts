import GameService from './GameService';

export default GameService;
