import JournalService from './JournalService';

export default JournalService;
