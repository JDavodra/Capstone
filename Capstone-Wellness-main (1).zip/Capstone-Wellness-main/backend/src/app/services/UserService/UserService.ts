import { UserMongo } from '../../database';

class UserService {
    // gets user info
    public login = () => {
        return UserMongo.login;
    };
    // adds user
    public register = () => {
        return UserMongo.register;
    };
    // updates user info
    public updateUser = () => {
        return UserMongo.updateUser;
    }
    // gets list all users
    public getAllUsers = () => {
        return UserMongo.getAllUsers;
    }
    // get a specific user
    public getUser = () => {
        return UserMongo.getUser;
    };
}

export default UserService;
