import UserService from './UserService';

export default UserService;
