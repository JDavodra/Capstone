import WellnessNewsService from './WellnessNewsService';

export {WellnessNewsService};
