import WellnessTipService from './WellnessTipService';

export { WellnessTipService };
