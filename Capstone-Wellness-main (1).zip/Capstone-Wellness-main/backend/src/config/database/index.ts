import database from './database';

export default database;
