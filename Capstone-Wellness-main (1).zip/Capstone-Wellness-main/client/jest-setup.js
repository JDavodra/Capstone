jest.useFakeTimers()

// Silence the warning: Animated: `useNativeDriver` is not supported because the native animated module is missing
jest.mock('@react-navigation/native')

jest.mock('react-native-gesture-handler')

jest.mock('@expo/vector-icons/AntDesign')

jest.mock('react-native-vector-icons/AntDesign')