import ActivitiesBookingsListAPI from './activitiesBookingsListAPI';

export default ActivitiesBookingsListAPI;
