import authAPI from './authAPI';

export default authAPI;
