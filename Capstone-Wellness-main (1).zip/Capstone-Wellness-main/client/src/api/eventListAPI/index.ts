import EventListAPI from './eventListAPI';

export default EventListAPI;
