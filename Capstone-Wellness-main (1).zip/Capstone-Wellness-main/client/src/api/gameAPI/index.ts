import gameAPI from './gameAPI';

export default gameAPI;
