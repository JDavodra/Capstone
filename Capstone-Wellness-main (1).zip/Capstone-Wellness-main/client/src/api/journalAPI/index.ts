import journalAPI from './journalAPI';

export default journalAPI;
