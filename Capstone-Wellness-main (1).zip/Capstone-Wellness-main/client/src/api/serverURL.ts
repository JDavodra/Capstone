import Constants from 'expo-constants';

let serverURL: string;
if (__DEV__) {
  // If hostUri exists (mobile), use it for backend API. Otherwise use local host
  serverURL = Constants.manifest.hostUri ? ("http://" + Constants.manifest.hostUri.split(':')[0] + ":3000") : ("http://localhost:3000");
} else {
  // Heroku production server
  serverURL = 'https://wellness-app-summer-2022.herokuapp.com';
}
console.log("Server is on: " + serverURL);

export default serverURL;
