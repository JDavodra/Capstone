import WellnessNewsListAPI from './wellnessNewsListAPI';

export default WellnessNewsListAPI;
