import wellnessTipsAPI from './wellnessTipsAPI';

export default wellnessTipsAPI;
