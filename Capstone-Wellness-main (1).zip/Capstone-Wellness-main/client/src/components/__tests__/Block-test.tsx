import * as React from 'react';
import renderer from 'react-test-renderer';

import Block from '../Block'

it(`renders correctly`, () => {
  const tree = renderer.create(<Block/>).toJSON();
  expect(tree).toMatchSnapshot();
});