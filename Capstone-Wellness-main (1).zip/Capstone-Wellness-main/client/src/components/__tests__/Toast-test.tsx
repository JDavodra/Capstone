import * as React from 'react';
import renderer from 'react-test-renderer';

import Toast from '../Toast'

it(`renders correctly`, () => {
  const tree = renderer.create(<Toast/>).toJSON();
  expect(tree).toMatchSnapshot();
});