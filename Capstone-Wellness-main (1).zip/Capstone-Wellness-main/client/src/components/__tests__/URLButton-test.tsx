import * as React from 'react';
import renderer from 'react-test-renderer';

import URLButtonProps from '../URLButton'

it(`renders correctly`, () => {
  const tree = renderer.create(<URLButtonProps url={''} title={''} buttonStyle={undefined}/>).toJSON();
  expect(tree).toMatchSnapshot();
});