import JournalContext from "./JournalContext";

export default JournalContext;
