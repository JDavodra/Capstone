import ActivitiesBookingsListContext from './activitiesBookingsListContext';

export default ActivitiesBookingsListContext;
