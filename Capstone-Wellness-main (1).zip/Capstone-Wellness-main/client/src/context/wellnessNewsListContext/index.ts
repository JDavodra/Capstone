import WellnessNewsListContext from './wellnessNewsListContext';

export default WellnessNewsListContext;
