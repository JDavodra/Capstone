import WellnessTipsContext from './wellnessTipsContext';

export default WellnessTipsContext;
