import IWellnessNews from './WellnessNewsInterface';
import { convertToWellnessNews, convertToWellnessNewsJSON} from './WellnessNewsConverter';

export { IWellnessNews, convertToWellnessNews, convertToWellnessNewsJSON};
