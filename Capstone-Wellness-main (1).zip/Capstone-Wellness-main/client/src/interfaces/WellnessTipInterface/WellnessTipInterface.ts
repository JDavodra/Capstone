export default interface IWellnessTip {
  //can be used in the future if needed
  date: string
  specialDay: string
  source: string
  tipOfTheDay: string
};
