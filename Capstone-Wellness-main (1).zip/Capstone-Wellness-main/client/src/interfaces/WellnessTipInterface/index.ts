import IWellnessTip from './WellnessTipInterface';
export { IWellnessTip };