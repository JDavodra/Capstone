import * as Linking from 'expo-linking';

// Hierarchy of local screens within each page on bottom navigation bar
export default {
  prefixes: [Linking.makeUrl('/')],
  config: {
    screens: {
      Root: {
        screens: {
          Home: {
            screens: {
              Home: 'home',
              BookService: 'bookService'
            },
          },
          Events: {
            screens: {
              Events: 'events',
            },
          },
          'Self-Help': {
            screens: {
              'Self-Help': 'self-help',
            },
          },
          Contact: {
            screens: {
              Contact: 'contact',
              SocialIntents: 'peer-wellness-chat',
              BookSession: 'book-session',
              BookPetTherapy: 'book-pet-therapy'
            },
          },
          Profile: {
            screens: {
              Profile: 'profile',
              Register: 'register',
              Login: 'login'
            },
          },
        },
      },
      NotFound: '*',
    },
  },
};
