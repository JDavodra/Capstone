import Angry from "./Angry";
export default Angry;