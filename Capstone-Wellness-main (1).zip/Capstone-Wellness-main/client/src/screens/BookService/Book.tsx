import * as React from 'react';
import { WebView } from 'react-native-webview';
import { useNavigation } from '@react-navigation/native';

export default function BookService({route}: {route: any} ) {
  /* Get the param */
  const navigation = useNavigation();
  const {service} = route.params;

  /* updating header title, refer to the 'BottomTabNavigator' for more info */
  
  navigation.setOptions({ title: service.descriptionEN })

  return (
    <WebView
      scrollEnabled={true}
      startInLoadingState={true}
      source={{ uri: service.urlEN }}
    />
  );
}
