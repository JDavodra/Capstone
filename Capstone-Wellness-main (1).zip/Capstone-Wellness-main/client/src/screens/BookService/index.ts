import BookService from './Book';
export default BookService;
