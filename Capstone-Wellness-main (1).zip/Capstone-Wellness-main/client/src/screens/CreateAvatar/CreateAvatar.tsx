import * as React from 'react';


import { Component, useEffect, useState } from 'react';
import { ScrollView, TouchableOpacity, SafeAreaView, ActivityIndicator, Dimensions } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Text, View } from '../../components/Themed';
import styles from './styles';
import WebView from 'react-native-webview';

import { List, Button } from 'react-native-paper';
import { FlatGrid } from 'react-native-super-grid';
import { connect, useDispatch } from 'react-redux';

import AuthActions from '../../store/auth/actions';
import Points from '../../constants/Points';
import { Appearance } from 'react-native-appearance';
import darkModeStyles from './darkModeStyles';
import { RFPercentage } from 'react-native-responsive-fontsize';


//Array containing all the options for the 
const topOptions = [
  { value: "NoHair", label: "No Hair" },
  { value: "Eyepatch", label: "Eyepatch" },
  { value: "Hat", label: "Hat" },
  { value: "Hijab", label: "Hijab" },
  { value: "Turban", label: "Turban" },
  { value: "WinterHat1", label: "Winter Hat 1" },
  { value: "WinterHat2", label: "Winter Hat 2" },
  { value: "WinterHat3", label: "Winter Hat 3" },
  { value: "WinterHat4", label: "Winter Hat 4" },
  { value: "LongHairBigHair", label: "Long and Big Hair" },
  { value: "LongHairBob", label: "Long Hair Bob" },
  { value: "LongHairBun", label: "Long Hair Bun" },
  { value: "LongHairCurly", label: "Long Hair Curly" },
  { value: "LongHairCurvy", label: "Long Hair Curvy" },
  { value: "LongHairDreads", label: "Long Hair Dreads" },
  { value: "LongHairFrida", label: "Long Hair Frida" },
  { value: "LongHairFro", label: "Long Hair Fro" },
  { value: "LongHairFroBand", label: "Long Hair Fro Band" },
  { value: "LongHairNotTooLong", label: "Semi Long Hair" },
  { value: "LongHairMiaWallace", label: "Long Mia Wallace" },
  { value: "LongHairStraight", label: "Long Hair Straight 1" },
  { value: "LongHairStraight2", label: "Long Hair Straight 2" },
  { value: "LongHairStraightStrand", label: "Long Straight Strand" },
  { value: "ShortHairDreads01", label: "Short Dreads 1" },
  { value: "ShortHairDreads02", label: "Short Dreads 2" },
  { value: "ShortHairFrizzle", label: "ShortH air Frizzle" },
  { value: "ShortHairShaggyMullet", label: "Short Shaggy Mullet" },
  { value: "ShortHairShortCurly", label: "Short Curly" },
  { value: "ShortHairShortFlat", label: "Short Flat" },
  { value: "ShortHairShortRound", label: "Short Round" },
  { value: "ShortHairShortWaved", label: "Short Waved" },
  { value: "ShortHairSides", label: "Short Hair Sides" },
  { value: "ShortHairTheCaesar", label: "The Caesar" },
  { value: "ShortHairTheCaesarSidePart", label: "Caesar Side Part" }
];
//Array containing all the options for the accesories
const accesoriesOptions = [
  { value: "Blank", label: "Blank" },
  { value: "Kurt", label: "Kurt" },
  { value: "Prescription01", label: "Prescription 1" },
  { value: "Prescription02", label: "Prescription 2" },
  { value: "Round", label: "Round" },
  { value: "Sunglasses", label: "Sunglasses" },
  { value: "Wayfarers", label: "Wayfarers" }
];
//Array containing all the options for the hairColor
const hairColorOptions = [
  { value: "Auburn", label: "Auburn" },
  { value: "Black", label: "Black" },
  { value: "Blonde", label: "Blonde" },
  { value: "BlondeGolden", label: "Blonde Golden" },
  { value: "Brown", label: "Brown" },
  { value: "BrownDark", label: "Brown Dark" },
  { value: "PastelPink", label: "Pastel Pink" },
  { value: "Platinum", label: "Platinum" },
  { value: "Red", label: "Red" },
  { value: "SilverGray", label: "Silver Gray" },
];
//Array containing all the options for the facial hair
const facialHairOptions = [
  { value: "Blank", label: "Blank" },
  { value: "BeardMedium", label: "Beard Medium" },
  { value: "BeardLight", label: "Beard Light" },
  { value: "BeardMajestic", label: "Beard Majestic" },
  { value: "MoustacheFancy", label: "Moustache Fancy" },
  { value: "MoustacheMagnum", label: "Moustache Magnum" },
];
//Array containing all the options for the clothes
const clothesOptions = [
  { value: "BlazerShirt", label: "Blazer Shirt" },
  { value: "BlazerSweater", label: "Blazer Sweater" },
  { value: "CollarSweater", label: "Collar Sweater" },
  { value: "GraphicShirt", label: "Graphic Shirt" },
  { value: "Hoodie", label: "Hoodie" },
  { value: "Overall", label: "Overall" },
  { value: "ShirtCrewNeck", label: "Shirt Crew-Neck" },
  { value: "ShirtScoopNeck", label: "Shirt Scoop-Neck" },
  { value: "ShirtVNeck", label: "Shirt V-Neck" },
];
//Array containing all the options for the eyes
const eyesOptions = [
  { value: "Close", label: "Close" },
  { value: "Cry", label: "Cry" },
  { value: "Default", label: "Default" },
  { value: "Dizzy", label: "Dizzy" },
  { value: "EyeRoll", label: "EyeRoll" },
  { value: "Happy", label: "Happy" },
  { value: "Hearts", label: "Hearts" },
  { value: "Side", label: "Side" },
  { value: "Squint", label: "Squint" },
  { value: "Surprised", label: "Surprised" },
  { value: "Wink", label: "Wink" },
  { value: "WinkWacky", label: "WinkWacky" },
];
//Array containing all the options for the mouth
const mouthOptions = [
  { value: "Concerned", label: "Concerned" },
  { value: "Default", label: "Default" },
  { value: "Disbelief", label: "Disbelief" },
  { value: "Eating", label: "Eating" },
  { value: "Grimace", label: "Grimace" },
  { value: "Sad", label: "Sad" },
  { value: "ScreamOpen", label: "Scream Open" },
  { value: "Serious", label: "Serious" },
  { value: "Smile", label: "Smile" },
  { value: "Tongue", label: "Tongue" },
  { value: "Twinkle", label: "Twinkle" },
  { value: "Vomit", label: "Vomit" },
];
//Array containing all the options for the skin
const skinOptions = [
  { value: "Tanned", label: "Tanned" },
  { value: "Yellow", label: "Yellow" },
  { value: "Pale", label: "Pale" },
  { value: "Light", label: "Light" },
  { value: "Brown", label: "Brown" },
  { value: "DarkBrown", label: "Dark Brown" },
  { value: "Black", label: "Black" },
];
//Array containing all the options for the eyebrows
const eyebrowOptions = [
  { value: "Angry", label: "Angry" },
  { value: "AngryNatural", label: "Angry Natural" },
  { value: "Default", label: "Default" },
  { value: "DefaultNatural", label: "Default Natural" },
  { value: "FlatNatural", label: "Flat Natural" },
  { value: "RaisedExcited", label: "Raised Excited" },
  { value: "RaisedExcitedNatural", label: "Raised Excited Natural" },
  { value: "SadConcerned", label: "Sad Concerned" },
  { value: "SadConcernedNatural", label: "Sad Concerned Natural" },
  { value: "UnibrowNatural", label: "Unibrow Natural" },
  { value: "UpDown", label: "Up Down" },
  { value: "UpDownNatural", label: "Up Down Natural" },
];

interface CreateAvatarProps extends Component {
  auth: any,
  errors: any
}

interface CreateAvatar {
  email: String,
  password: String
}

const mapStateToProps = (state: CreateAvatarProps) => ({
  auth: state.auth,
  errors: state.errors
});
//this screen has access to the props values
const CreateAvatar: React.FC<CreateAvatarProps> = (props: CreateAvatarProps) => {


  const navigation = useNavigation();
  const dispatch = useDispatch();

  //Create Avatar on first load
  useEffect(() => {
    //url used to fetch the avatar
    setcurrentHtml("<center><img width='400' height='400' src='https://avataaars.io/?avatarStyle=Circle&topType=" + props.auth.user.avatar.top + "&accessoriesType=" + props.auth.user.avatar.accessories + "&hairColor=" + props.auth.user.avatar.hairColor + "&facialHairType=" + props.auth.user.avatar.facialHair + "&facialHairColor=Brown&clotheType=" + props.auth.user.avatar.clothes + "&clotheColor=Blue03&eyeType=" + props.auth.user.avatar.eyes + "&eyebrowType=" + props.auth.user.avatar.eyebrows + "&mouthType=" + props.auth.user.avatar.mouth + "&skinColor=" + props.auth.user.avatar.skin + "'/><center>");
  }, []);

  //Refresh tip when screen goes out of focus
  useEffect(() => {
    const unsubscribe = () => {
      navigation.addListener('blur', (e) => {
        AuthActions.updateUser(props.auth.user);
      });
    }
    unsubscribe();
  }, [navigation]);

  //updating the URL that refresh the webview

  const [currentHtml, setcurrentHtml] = useState("<center><img width='400' height='400' src='https://avataaars.io/?avatarStyle=Circle&topType=" + props.auth.user.avatar.top + "&accessoriesType=" + props.auth.user.avatar.accessories + "&hairColor=" + props.auth.user.avatar.hairColor + "&facialHairType=" + props.auth.user.avatar.facialHair + "&facialHairColor=Brown&clotheType=" + props.auth.user.avatar.clothes + "&clotheColor=Blue03&eyeType=" + props.auth.user.avatar.eyes + "&eyebrowType=" + props.auth.user.avatar.eyebrows + "&mouthType=" + props.auth.user.avatar.mouth + "&skinColor=" + props.auth.user.avatar.skin + "'/><center>");

  //these methods will avoid to have all the dropdown list expending at the same time 
  const [expanded1, setExpanded1] = React.useState(false);
  const [expanded2, setExpanded2] = React.useState(false);
  const [expanded3, setExpanded3] = React.useState(false);
  const [expanded4, setExpanded4] = React.useState(false);
  const [expanded5, setExpanded5] = React.useState(false);
  const [expanded6, setExpanded6] = React.useState(false);
  const [expanded7, setExpanded7] = React.useState(false);
  const [expanded8, setExpanded8] = React.useState(false);
  const [expanded9, setExpanded9] = React.useState(false);

  //manage the expanded sections
  function handleAccordionPressed(num: number) {
    setExpanded1(false);
    setExpanded2(false);
    setExpanded3(false);
    setExpanded4(false);
    setExpanded5(false);
    setExpanded6(false);
    setExpanded7(false);
    setExpanded8(false);
    setExpanded9(false);

    switch (num) {
      case 1:
        setExpanded1(!expanded1);
        break;
      case 2:
        setExpanded2(!expanded2);
        break;
      case 3:
        setExpanded3(!expanded3);
        break;
      case 4:
        setExpanded4(!expanded4);
        break;
      case 5:
        setExpanded5(!expanded5);
        break;
      case 6:
        setExpanded6(!expanded6);
        break;
      case 7:
        setExpanded7(!expanded7);
        break;
      case 8:
        setExpanded8(!expanded8);
        break;
      case 9:
        setExpanded9(!expanded9);
        break;

    }
  }


  //update the HTML that will be rendered in the webview
  //called everytime the user click on a button 

  function updateHTML(type: string, item: string) {

    //depending on the 'type' argument we change it

    if (type == "top") {
      props.auth.user.avatar.top = item;
    }
    if (type == "accessories") {
      props.auth.user.avatar.accessories = item;
    }
    if (type == "hairColor") {
      props.auth.user.avatar.hairColor = item;
    }
    if (type == "facialHair") {
      props.auth.user.avatar.facialHair = item;
    }
    if (type == "clothes") {
      props.auth.user.avatar.clothes = item;
    }
    if (type == "eyes") {
      props.auth.user.avatar.eyes = item;
    }
    if (type == "eyebrows") {
      props.auth.user.avatar.eyebrows = item;
    }
    if (type == "mouth") {
      props.auth.user.avatar.mouth = item;
    }
    if (type == "skin") {
      props.auth.user.avatar.skin = item;
    }

    //then we insert all the values inside the html
    let updatedHTML = "<center><img width='400' height='400' src='https://avataaars.io/?avatarStyle=Circle&topType=" + props.auth.user.avatar.top + "&accessoriesType=" + props.auth.user.avatar.accessories + "&hairColor=" + props.auth.user.avatar.hairColor + "&facialHairType=" + props.auth.user.avatar.facialHair + "&facialHairColor=Brown&clotheType=" + props.auth.user.avatar.clothes + "&clotheColor=Blue03&eyeType=" + props.auth.user.avatar.eyes + "&eyebrowType=" + props.auth.user.avatar.eyebrows + "&mouthType=" + props.auth.user.avatar.mouth + "&skinColor=" + props.auth.user.avatar.skin + "'/><center>";
    setcurrentHtml(updatedHTML);

  }

  //saves the avatar in the redux store of the user
  function saveAvatar() {

    //updating the game collection
    if (props.auth.game.avatarCreated == false) {
      //if it is the first time a user created the avatar, they earn points
      AuthActions.addPoints(Points.createAvatarPoints);
      AuthActions.setBooleanValue('avatarCreated',true);
    }

    //Adding the new avatr to the DB
    let updatedUser = props.auth.user;
    AuthActions.updateUser(updatedUser);
    
    navigation.goBack();
  }

  const [theme, setTheme] = useState(Appearance.getColorScheme());
  // handles light/dark mode appearance
  useEffect(() => {
      const subscription = Appearance.addChangeListener(({ colorScheme }) => {
      setTheme(colorScheme);
      });
      return () => subscription.remove();
  }, []);

  const {width} = Dimensions.get("window");
  
  return (
    <SafeAreaView style={theme === 'light' ? styles.container : darkModeStyles.container}>

      <ScrollView contentContainerStyle={styles.scrollContainer} scrollEnabled={false} style={{height: '55%'}}>
        <Text style={styles.subtitle}>Create your avatar</Text>
       
          <WebView
            scrollEnabled={false}
            originWhitelist={['*']}
            style={{ backgroundColor: 'transparent', flex: 1, minHeight: 420 }}
            //style={{marginTop: 300, flex: 1, width:450, height:500}}
            source={{ html: currentHtml }}
            startInLoadingState={true}
            renderLoading={() => (
              <ActivityIndicator
                color='blue'
                size='large'
                style={{ flex: 1 }}
              />)}
          />
      </ScrollView>

      <ScrollView contentContainerStyle={styles.scrollContainer}>

        {/* The first selector for the Top element */}

        <List.Accordion
          title="Skin"
          expanded={expanded9}
          onPress={() => handleAccordionPressed(9)}
          style={{backgroundColor: theme === 'light' ? '#f6f6f6' : '#262626'}}
          theme={{ colors: { primary: theme === 'light' ? 'black' : 'white', background: theme === 'light' ? '#fcfcfc' : 'black',
              text: theme === 'light' ? 'black' : 'white' }}} 
          titleStyle={theme === 'light' ? styles.titleList : darkModeStyles.titleList}>
          <FlatGrid
            itemDimension={width/4}
            data={skinOptions}
            style={styles.gridView}
            renderItem={({ item }) => (
              <TouchableOpacity style={[styles.itemContainer, { backgroundColor: theme === 'light' ? 'rgb(210,207,200)' : '#a19f9a'}]} onPress={() => updateHTML("skin", item.value)}>
                <Text style={styles.itemName}>{item.label}</Text>
              </TouchableOpacity>
            )}
          />
        </List.Accordion>
        <List.Accordion
          title="Eyes"
          expanded={expanded6}
          onPress={() => handleAccordionPressed(6)}
          style={{backgroundColor: theme === 'light' ? '#f6f6f6' : '#262626'}}
          theme={{ colors: { primary: theme === 'light' ? 'black' : 'white', background: theme === 'light' ? '#fcfcfc' : 'black',
              text: theme === 'light' ? 'black' : 'white' }}} 
          titleStyle={theme === 'light' ? styles.titleList : darkModeStyles.titleList}>
          <FlatGrid
            itemDimension={width/4}
            data={eyesOptions}
            style={styles.gridView}
            renderItem={({ item }) => (
              <TouchableOpacity style={[styles.itemContainer, { backgroundColor: theme === 'light' ? '#f9ce62' : '#f7c136'}]} onPress={() => updateHTML("eyes", item.value)}>
                <Text style={styles.itemName}>{item.label}</Text>
              </TouchableOpacity>
            )}
          />

        </List.Accordion>

        <List.Accordion
          title="Eyebrows"
          expanded={expanded7}
          onPress={() => handleAccordionPressed(7)}
          style={{backgroundColor: theme === 'light' ? '#f6f6f6' : '#262626'}}
          theme={{ colors: { primary: theme === 'light' ? 'black' : 'white', background: theme === 'light' ? '#fcfcfc' : 'black',
              text: theme === 'light' ? 'black' : 'white' }}} 
          titleStyle={theme === 'light' ? styles.titleList : darkModeStyles.titleList}>
          <FlatGrid
            itemDimension={width/4}
            data={eyebrowOptions}
            style={styles.gridView}
            renderItem={({ item }) => (
              <TouchableOpacity style={[styles.itemContainer, { backgroundColor: '#ea7754' }]} onPress={() => updateHTML("eyebrows", item.value)}>
                <Text style={styles.itemName}>{item.label}</Text>
              </TouchableOpacity>
            )}
          />
        </List.Accordion>

        <List.Accordion
          title="Mouth"
          expanded={expanded8}
          onPress={() => handleAccordionPressed(8)}
          style={{backgroundColor: theme === 'light' ? '#f6f6f6' : '#262626'}}
          theme={{ colors: { primary: theme === 'light' ? 'black' : 'white', background: theme === 'light' ? '#fcfcfc' : 'black',
            text: theme === 'light' ? 'black' : 'white' }}} 
          titleStyle={theme === 'light' ? styles.titleList : darkModeStyles.titleList}>
          <FlatGrid
            itemDimension={width/4}
            data={mouthOptions}
            style={styles.gridView}
            renderItem={({ item }) => (
              <TouchableOpacity style={[styles.itemContainer, { backgroundColor: '#8f001a' }]} onPress={() => updateHTML("mouth", item.value)}>
                <Text style={styles.itemName}>{item.label}</Text>
              </TouchableOpacity>
            )}
          />
        </List.Accordion>

        <List.Accordion

          title="Top"
          expanded={expanded1}
          onPress={() => handleAccordionPressed(1)}
          style={{backgroundColor: theme === 'light' ? '#f6f6f6' : '#262626'}}
          theme={{ colors: { primary: theme === 'light' ? 'black' : 'white', background: theme === 'light' ? '#fcfcfc' : 'black',
              text: theme === 'light' ? 'black' : 'white' }}} 
          titleStyle={theme === 'light' ? styles.titleList : darkModeStyles.titleList}>
          <FlatGrid
            itemDimension={width/4}
            data={topOptions}
            style={styles.gridView}
            renderItem={({ item }) => (
              <TouchableOpacity style={[styles.itemContainer, { backgroundColor: '#91af51' }]} onPress={() => updateHTML("top", item.value)}>
                <Text style={styles.itemName}>{item.label}</Text>
              </TouchableOpacity>
            )}
          />

        </List.Accordion>

        <List.Accordion
          title="Hair Color"
          expanded={expanded3}
          onPress={() => handleAccordionPressed(3)}
          style={{backgroundColor: theme === 'light' ? '#f6f6f6' : '#262626'}}
          theme={{ colors: { primary: theme === 'light' ? 'black' : 'white', background: theme === 'light' ? '#fcfcfc' : 'black',
              text: theme === 'light' ? 'black' : 'white' }}} 
          titleStyle={theme === 'light' ? styles.titleList : darkModeStyles.titleList}>
          <FlatGrid
            itemDimension={width/4}
            data={hairColorOptions}
            style={styles.gridView}
            renderItem={({ item }) => (
              <TouchableOpacity style={[styles.itemContainer, { backgroundColor: theme === 'light' ? '#4ac1c0' : '#2badab'}]} onPress={() => updateHTML("hairColor", item.value)}>
                <Text style={styles.itemName}>{item.label}</Text>
              </TouchableOpacity>
            )}
          />

        </List.Accordion>

        <List.Accordion
          title="Facial Hair"
          expanded={expanded4}
          onPress={() => handleAccordionPressed(4)}
          style={{backgroundColor: theme === 'light' ? '#f6f6f6' : '#262626'}}
          theme={{ colors: { primary: theme === 'light' ? 'black' : 'white', background: theme === 'light' ? '#fcfcfc' : 'black',
              text: theme === 'light' ? 'black' : 'white' }}} 
          titleStyle={theme === 'light' ? styles.titleList : darkModeStyles.titleList}>
          <FlatGrid
            itemDimension={width/4}
            data={facialHairOptions}
            style={styles.gridView}
            renderItem={({ item }) => (
              <TouchableOpacity style={[styles.itemContainer, { backgroundColor: '#9b65ba' }]} onPress={() => updateHTML("facialHair", item.value)}>
                <Text style={styles.itemName}>{item.label}</Text>
              </TouchableOpacity>
            )}
          />

        </List.Accordion>

        <List.Accordion
          title="Clothes"
          expanded={expanded5}
          onPress={() => handleAccordionPressed(5)}
          style={{backgroundColor: theme === 'light' ? '#f6f6f6' : '#262626'}}
          theme={{ colors: { primary: theme === 'light' ? 'black' : 'white', background: theme === 'light' ? '#fcfcfc' : 'black',
              text: theme === 'light' ? 'black' : 'white' }}} 
          titleStyle={theme === 'light' ? styles.titleList : darkModeStyles.titleList}>
          <FlatGrid
            itemDimension={width/4}
            data={clothesOptions}
            style={styles.gridView}
            renderItem={({ item }) => (
              <TouchableOpacity style={[styles.itemContainer, { backgroundColor: '#7063ba' }]} onPress={() => updateHTML("clothes", item.value)}>
                <Text style={styles.itemName}>{item.label}</Text>
              </TouchableOpacity>
            )}
          />

        </List.Accordion>


        <List.Accordion
          title="Accessories"
          expanded={expanded2}
          onPress={() => handleAccordionPressed(2)}
          style={{backgroundColor: theme === 'light' ? '#f6f6f6' : '#262626'}}
          theme={{ colors: { primary: theme === 'light' ? 'black' : 'white', background: theme === 'light' ? '#fcfcfc' : 'black',
              text: theme === 'light' ? 'black' : 'white' }}} 
          titleStyle={theme === 'light' ? styles.titleList : darkModeStyles.titleList}>
          <FlatGrid
            itemDimension={width/4}
            data={accesoriesOptions}
            style={styles.gridView}
            renderItem={({ item }) => (
              <TouchableOpacity style={[styles.itemContainer, { backgroundColor: '#104291' }]} onPress={() => updateHTML("accessories", item.value)}>
                <Text style={styles.itemName}>{item.label}</Text>
              </TouchableOpacity>
            )}
          />

        </List.Accordion>

        <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: theme === 'light' ? 'white' : '#171717'}}>
          <Button
            mode='contained'
            icon="check"
            labelStyle={{fontFamily: 'BarlowCondensed_500Medium',fontSize:RFPercentage(2.5)}}
            style={styles.buttonSubmit}
            onPress={() => saveAvatar()}>
            Save Avatar
          </Button>
        </View>

      </ScrollView>
    </SafeAreaView>

  );
}

export default connect(mapStateToProps)(CreateAvatar);