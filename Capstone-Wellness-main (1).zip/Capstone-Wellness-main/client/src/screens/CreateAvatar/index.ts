import CreateAvatar from './CreateAvatar';
export default CreateAvatar;
