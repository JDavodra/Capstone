import { StyleSheet } from 'react-native';
import { RFPercentage } from 'react-native-responsive-fontsize';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: '#ffffff'
  },
  title: {
    //fontSize: 25,
    fontSize: RFPercentage(3.7),
    fontWeight: '900',
    paddingHorizontal: '7%',
    marginTop: 10,
    marginBottom: 5,
    color: 'black',
    fontFamily: 'BarlowCondensed_500Medium'
  },
  //used for the pop up window 
  modal: {
    margin: 10,
    backgroundColor: "#D4F0F0",
    borderRadius: 30,
    paddingTop:10,
    padding: 0,
    alignItems: "center",
    shadowColor: "#0000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 5
  },

  modalWebView: {
    margin: 10,
    backgroundColor: "white",
    borderRadius: 20,
    padding: 10,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 5,
  },
  modalImage: {
      marginTop:15,
      marginBottom:15,
      width: 200,
      height: 200,
  
  },
  modalImageCircle: {
    marginTop:15,
    marginBottom:15,
    width: 200,
    height: 200,
    borderRadius:240,

},
  modalText: {
    marginBottom: 15,
    textAlign: "center"
  },
  modalRewardText: {
    marginBottom: 15,
    paddingBottom:10,
    textAlign: "center",
    // fontSize: 21,
    fontSize: RFPercentage(2.8),
    fontWeight: '700',
    paddingHorizontal: '7%',
    color:"green",
    fontFamily: 'BarlowCondensed_400Regular'
  },
  modalExplanationText: {
    marginBottom: 15,
    textAlign: "left",
    // fontSize: 19,
    fontSize: RFPercentage(2.8),
    fontWeight: '600',
    paddingHorizontal: '7%',
    fontFamily: 'BarlowCondensed_500Medium',
    color: 'black'
  },
  buttonTrue: {
    marginTop: 15,
    width: 169,
    height: 40,
    borderRadius: 16,
    // fontSize: 10,
    fontSize: RFPercentage(2.5),
    justifyContent: 'center',
    alignContent: 'center',
    alignSelf: 'center',
    alignItems: 'center',
    backgroundColor: "#97C1A9",
  },
  buttonFalse: {
    marginTop: 15,
    width: 169,
    height: 40,
    borderRadius: 16,
    fontSize: 10,
    justifyContent: 'center',
    alignContent: 'center',
    alignSelf: 'center',
    alignItems: 'center',
    backgroundColor: "#FF968A",
  },
  buttonSource: {
    marginTop: 15,
    marginBottom: 15,
    width: 169,
    height: 40,
    borderRadius: 16,
    // fontSize: 10,
    fontSize: RFPercentage(2.5),
    justifyContent: 'center',
    alignContent: 'center',
    alignSelf: 'center',
    alignItems: 'center',
    backgroundColor: "#A2E1DB",
  },
  rewardMessage: {
    marginTop:10,
    // fontSize: 21,
    fontSize: RFPercentage(2.7),
    fontWeight: '700',
    paddingHorizontal: '7%'
  },
  
});

export default styles;
