import EventDetails from "./EventDetails";

export default EventDetails;