import FilterSearchPage from "./FilterSearchPage";
export default FilterSearchPage;