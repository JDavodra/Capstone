//
import * as React from 'react';
import { Divider} from 'react-native-elements';
import { ScrollView, TouchableOpacity, SafeAreaView, TextInput, KeyboardAvoidingView, Platform} from 'react-native';
import { connect } from "react-redux";
import { useNavigation } from '@react-navigation/native';
import darkModeStyles from './darkModeStyles';
import { Text, View } from '../../components/Themed';
import styles from './styles';
import { AntDesign } from '@expo/vector-icons'; 
import { JournalContext } from '../../context';
import { useEffect, useState } from 'react';
import {Appearance} from 'react-native-appearance';
import { RFPercentage } from 'react-native-responsive-fontsize';

interface GratitudeProps {

  auth: any;
  
}

const mapStateToProps = (state: GratitudeProps) => ({
  auth: state.auth,
});

const Gratitude: React.FC<GratitudeProps> = (props: GratitudeProps) => {
  const navigation = useNavigation();

  const [theme, setTheme] = useState(Appearance.getColorScheme());
  
  // handles light/dark mode appearance
  useEffect(() => {
    const subscription = Appearance.addChangeListener(({ colorScheme }) => {
      setTheme(colorScheme);
    });
    return () => subscription.remove();
  }, []);

  // Gets all of user's entries at the beginning and stores in array called entries init above. No need to touch this
  
  
  const [entry, setEntry] = React.useState('');
  const handlePress = () => {
    const entryToAdd = {
      userId: props.auth.user.id,
      title: 'Feeling Grateful',
      entry: entry
    }
    JournalContext.addEntry(entryToAdd)
    navigation.navigate('Journal')
    
    
    
  };
  //The components to book the different services 
  
  return (
    <SafeAreaView style={theme === 'light' ? styles.container : darkModeStyles.container}>
      
      <View style={theme === 'light' ? styles.titleContainer : darkModeStyles.titleContainer}>
        <Text style={styles.titlePage}>Grateful</Text>
        <View style={theme === 'light' ? styles.backContainer : darkModeStyles.backContainer}>
          <AntDesign onPress={() => navigation.goBack()} name="close" style={{fontSize: RFPercentage(3.8)}}
            color={theme === 'light' ? 'black' : 'white'} />
        </View>
      </View>
      <View style={theme === 'light' ? styles.questionContainer : darkModeStyles.questionContainer}>
        <Text style={styles.title}>Write 5 things you are grateful for today no matter how small the importance?{"\n"}What do you value most in life?</Text>
      </View>
        
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <TextInput
          style={theme === 'light' ? styles.input : darkModeStyles.input}
          placeholder="Start writing..."
          multiline
          placeholderTextColor={'#525252'}
          onChangeText={entry => setEntry(entry)} 
        />
      </ScrollView>

      <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <View style={styles.bottomContainer}>
        <Divider style = { styles.dividerButton }/>
        <View style = {styles.buttonContainer}>
          <View style={theme === 'light' ? styles.button : darkModeStyles.button}>
            <Text style={styles.delete}></Text>
          </View>
          <TouchableOpacity style={theme === 'light' ? styles.button : darkModeStyles.button} onPress={() => handlePress()} >
            <Text style={styles.save}>Save</Text>
          </TouchableOpacity>
        </View>
      </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
export default connect(mapStateToProps)(Gratitude);