import Insecure from "./Insecure";
export default Insecure;