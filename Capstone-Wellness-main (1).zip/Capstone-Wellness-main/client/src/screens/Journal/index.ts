import Journal from './Journal';

export default Journal;
