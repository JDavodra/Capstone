import JournalEntry from './JournalEntry';
export default JournalEntry;