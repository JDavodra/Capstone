import Leaderboard from './Leaderboard';
export default Leaderboard;