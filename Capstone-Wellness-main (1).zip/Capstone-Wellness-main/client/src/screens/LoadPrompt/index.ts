import LoadPrompt from './LoadPrompt';
export default LoadPrompt;