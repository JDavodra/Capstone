import React, { Component, useEffect, useState } from 'react';
import { connect } from "react-redux";
import { ScrollView, TouchableOpacity } from 'react-native';
import { Input } from 'react-native-elements';
import { Formik } from 'formik';
import { useNavigation } from '@react-navigation/native';
import * as yup from 'yup';

import { Ionicons } from '@expo/vector-icons';

import { Text, View } from '../../components/Themed';
import styles from './styles';

import AuthActions from "../../store/auth/actions";
import { Appearance } from 'react-native-appearance';
import { RFPercentage } from 'react-native-responsive-fontsize';

// this file does not a stylesheet for darkModeStyles.tsx,
// because only 2 changes were needed to support dark mode


interface LoginProps extends Component {
    auth: any,
    errors: any
}

interface Login {
    email: String,
    password: String
}

const mapStateToProps = (state: LoginProps) => ({
    auth: state.auth,
    errors: state.errors
});

const Login: React.FC<LoginProps> = (props: LoginProps) => {
    const navigation = useNavigation();

    const onSubmit = (login: Login) => {
        // Login user
        AuthActions.login(login)
            .then(() => {
                // Get gamification info of user
                AuthActions.getGameInfo()
                    .then(() => {
                        // Redirect user to homepage if login & getting gamification data successful 
                        navigation.reset({ routes: [{ name: 'Home' }] }) 
                    })
                    .catch(() => { navigation.navigate('Login'); });; // Remain on login page if fetching gamification data fails
            })
            .catch(() => { navigation.navigate('Login'); }); // Remain on login page if signin fails
    };

    const validationSchema = yup.object().shape({
        // Required; Must be in email format
        email: yup
            .string()
            .email('Invalid email')
            .required('Please provide an email'),
        // Required; Password must be between 6-20 characters - numbers, letters, special characters all allowed
        password: yup
            .string()
            .min(6, 'Min. password length required: 6 characters')
            .max(20, 'Max. password length permitted: 20 characters')
            .required('Please enter a password (Hint: 6-20 characters)')
    });
    // Initial values set to blank, updates when user types
    const initialValues = {
        email: '',
        password: ''
    };

    const [theme, setTheme] = useState(Appearance.getColorScheme());
  
    // handles light/dark mode appearance
    useEffect(() => {
      const subscription = Appearance.addChangeListener(({ colorScheme }) => {
        setTheme(colorScheme);
      });
      return () => subscription.remove();
    }, []);

    return (
        <View style={styles.container}>
            <ScrollView>
                <Formik
                    initialValues={initialValues}
                    validationSchema={validationSchema}
                    onSubmit={(values: Login) => onSubmit(values)}
                >
                    {({ values, handleChange, errors, setFieldTouched, touched, handleSubmit }) => (
                        <View style={styles.formContainer}>
                            {/* Login form */}
                            <Input
                                placeholder='Email'
                                autoCapitalize='none'
                                onChangeText={handleChange('email')}
                                value={values.email}
                                errorMessage={touched.email && errors.email ? errors.email : ''}
                                errorStyle={{fontFamily: 'BarlowCondensed_400Regular', fontSize: RFPercentage(2.2)}}
                                onBlur={() => setFieldTouched('email')}
                                leftIcon={<Ionicons name='mail' color={theme === 'light' ? 'black' : 'white'} style={{fontSize: RFPercentage(1.6)}}/>}
                                style={[{color: theme === 'light' ? 'black': 'white'}, styles.input]}
                            />
                            <Input
                                placeholder='Password'
                                onChangeText={handleChange('password')}
                                value={values.password}
                                errorMessage={touched.password && errors.password ? errors.password : ''}
                                errorStyle={{fontFamily: 'BarlowCondensed_400Regular', fontSize: RFPercentage(2.2)}}
                                passwordRules='minlength: 6'
                                onBlur={() => setFieldTouched('password')}
                                secureTextEntry={true}
                                leftIcon={<Ionicons name='lock-closed' color={theme === 'light' ? 'black' : 'white'} style={{fontSize: RFPercentage(1.6)}}/>}
                                style={[{color: theme === 'light' ? 'black': 'white'}, styles.input]}
                            />
                            
                            
                            
                            <TouchableOpacity style={styles.loginContainer} onPress={() => { handleSubmit() }}>
                                <Text style={styles.buttonLogin}>Login</Text>
                            </TouchableOpacity>
                            {/* Display error message if any */}
                        
                            {props.errors.password !== undefined ?
                                        <Text style={styles.error} >{props.errors['password']}</Text>
                                        : <Text style={styles.error} ></Text>}
                                        <Text></Text>           
                        </View>     
                    )}
                </Formik>
            </ScrollView>
        </View>
    );
}

export default connect(mapStateToProps)(Login);
