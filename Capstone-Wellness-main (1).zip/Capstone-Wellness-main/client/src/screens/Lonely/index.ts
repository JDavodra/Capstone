import Lonely from './Lonely';
export default Lonely;