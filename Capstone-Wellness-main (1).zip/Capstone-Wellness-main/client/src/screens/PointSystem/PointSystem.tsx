import * as React from 'react';
import { View,Text, SafeAreaView, Image, FlatList, Animated } from 'react-native';
import { ScrollView, TouchableOpacity } from 'react-native-gesture-handler';
import { FlatGrid } from 'react-native-super-grid';
import styles from './styles';
import ConfettiCannon from 'react-native-confetti-cannon';
import Points from '../../constants/Points';
import { Ionicons } from '@expo/vector-icons';

import { useNavigation } from '@react-navigation/native';
import { useEffect, useState } from 'react';
import { Appearance } from 'react-native-appearance';
import darkModeStyles from './darkModeStyles';


export default function PointSystem() {

  const navigation = useNavigation();

  const [theme, setTheme] = useState(Appearance.getColorScheme());
  
  // handles light/dark mode appearance
  useEffect(() => {
    const subscription = Appearance.addChangeListener(({ colorScheme }) => {
      setTheme(colorScheme);
    });
    return () => subscription.remove();
  }, []);

  //loading images 
  const badges = [
    { name: 'Bronze',icon:require('../../../assets/images/badges/bronze.png'),points:Points.bronze},
    { name: 'Silver',icon:require('../../../assets/images/badges/silver.png'),points:Points.silver},
    { name: 'Gold',icon:require('../../../assets/images/badges/gold.png'),points:Points.gold},
    { name: 'Platinum', icon:require('../../../assets/images/badges/platinum.png'),points:Points.platinum},
    { name: 'Diamond', icon:require('../../../assets/images/badges/diamond.png'),points:Points.diamond}, 
  ];

  //actiosn that can be performed to earn points 
  const actions = [
    { id: 'Creating account',frequency:'One-time', reward:Points.accountCreatedPoints},
    { id: 'Sharing Wellness Tip',frequency:'Daily', reward:Points.shareWellnessTipPoints},
    { id: 'Share an event', frequency:'Daily',reward:Points.shareEventPoints},
    { id: 'Create an avatar', frequency:'One-time',reward:Points.createAvatarPoints},
    { id: 'Enable notifications',frequency:'One-time', reward:Points.notificationActivated},
    { id: 'Complete daily mission',frequency:'Daily', reward:Points.dailyMissionCompletedPoints},
    // { id: 'Book a service',frequency:'Daily', reward:Points.serviceBookedPoints}

  ]

  

  return (
    <SafeAreaView style={theme === 'light' ? styles.container : darkModeStyles.container}>  
      
      <ScrollView >

        {/* <Text style={styles.title}>How to earn points ?</Text> */}
        <View style={styles.titleContainer}>
                    <Ionicons onPress={() => navigation.goBack()} name="chevron-back-outline"
                    color={theme === 'light' ? 'black' : 'white'} style={styles.back} />
                    <Text style={theme === 'light' ? styles.title : darkModeStyles.title}>How to earn points ?</Text>
        </View>
        <Text style={styles.subtitle}>Explanation.</Text>
        <Text style={theme === 'light' ? styles.body : darkModeStyles.body}>When exploring the Wellness App, you will find different actions helping you to earn points. From creating an avatar to sharing a wellness tip, these actions will allow you to earn points and redeem them later for rewards !  </Text>
        <Text> </Text>
        <Image style={styles.image} source={{uri:'https://www2.uottawa.ca/campus-life/sites/g/files/bhrskd281/files/styles/max_width_xl_5120px/public/2021-08/Wellness%20Lounge-getting-involved.jpg?itok=uc2u4xMX'}}/>
        <Text style={styles.subtitle}>Actions.</Text>
        <Text style={theme === 'light' ? styles.body : darkModeStyles.body}>Here is a list of a few of the actions you can complete to earn more points ! </Text>
        <FlatList
          data= {actions}
          renderItem={({ item }) => (
          <View style={styles.listcontainer}>
            <Text style={theme === 'light' ? styles.listitem : darkModeStyles.listitem}>{item.id}</Text>
            <Text style={[styles.listitem,{color:'#104291'}]}>{item.reward} points</Text>
            <Text style={[styles.listitem,{color:'#91af51'}]}>{item.frequency} </Text>
          </View>  
          )}
        /> 
        <Text></Text>
        <Text></Text>

        <Text style={styles.subtitle}>Badges.  </Text>

        <Text style={theme === 'light' ? styles.body : darkModeStyles.body}>The more points you earn to highest your rank will be ! To visualize your progress, you can simply check your badge. There are 5 different badges, here they are : </Text>
        <FlatGrid
          itemDimension={115}
          data= {badges}
          style={styles.gridView}
          renderItem={({ item }) => (
          <View style={styles.itemContainer}>
            <TouchableOpacity>
              <Image style={styles.itemImage} source={item.icon}></Image>
            </TouchableOpacity>
            
            <Text style={theme === 'light' ? styles.itemName : darkModeStyles.itemName}>{item.name}</Text>
            <Text style={theme === 'light' ? styles.itemName : darkModeStyles.itemName}>{item.points}</Text>
          </View>  
          )}
        /> 

        <Text style={styles.subtitle}>Streaks.  </Text>
        <Text style={theme === 'light' ? styles.body : darkModeStyles.body}>Everyday, you will be able to complete the "Daily Missions". These are short actions to complete, usually less than 20 seconds. After completing the action, you will recieve 10 points.
        But that's not all ! You will also receive an additional streak ! The more streak you get the greater your chance to get gifts at the end of the year !  </Text>

        <Image  style = {styles.image} source = {require('../../../assets/images/streak.png')} ></Image>
        {/* <Text style={[styles.body,{textAlign: 'center',alignContent: 'center',}]}>The streak icon.</Text> */}
        <Text/>
        

        <Text style={styles.subtitle}>Leaderboard.  </Text>
        <Text style={theme === 'light' ? styles.body : darkModeStyles.body}>Great news ! All the users are competing together ! You can access the leaderboard to see how you're doign compared to other. Your ranking in the leaderboard is also what's going to determine to price you will get. </Text>
        <Text/>
        <Text/>
        <Text style={styles.subtitle}>Rewards.  </Text>
        <Text style={theme === 'light' ? styles.body : darkModeStyles.body}>Depending on your badge, you will be elligible for prices at the end of the year ! More information will be communicated to you soon... </Text>
        <Image style={styles.image} source={{uri:'https://www.tekportal.net/wp-content/uploads/2018/11/reward.png'}}/>

      </ScrollView>
    </SafeAreaView>
  );
};
