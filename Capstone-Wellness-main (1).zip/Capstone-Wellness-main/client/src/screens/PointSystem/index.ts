import PointSystem from './PointSystem';
export default PointSystem;
