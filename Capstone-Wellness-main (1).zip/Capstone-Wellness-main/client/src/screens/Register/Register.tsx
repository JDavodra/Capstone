import React, { Component, useEffect, useState } from 'react';
import { connect } from "react-redux";
import { ScrollView, TouchableOpacity } from 'react-native';
import { Input } from 'react-native-elements';
import { Formik } from 'formik';
import { useNavigation } from '@react-navigation/native';
import * as yup from 'yup';

import { Ionicons } from '@expo/vector-icons';
//For future (adding calendar for birthday)
//import { Calendar, LocaleConfig } from 'react-native-calendars';

import { Text, View } from '../../components/Themed';
import styles from './styles';

import AuthActions from '../../store/auth/actions';
import { Appearance } from 'react-native-appearance';
import { RFPercentage } from 'react-native-responsive-fontsize';

// this file does not a stylesheet for darkModeStyles.tsx,
// because only few changes were needed to support dark mode


interface RegisterProps extends Component {
    auth: any;
    errors: any;
}

interface User {
    firstName: String,
    lastName: String,
    email: String,
    dateOfBirth: String,
    gender: String,
    password: String,
    passwordConfirm: String,
    phoneNumber: String,
    avatar: String
}

const mapStateToProps = (state: RegisterProps) => {
    return {
        auth: state.auth,
        errors: state.errors
    }
};

const Register: React.FC<RegisterProps> = (props: RegisterProps) => {
    const [theme, setTheme] = useState(Appearance.getColorScheme());
  
    // handles light/dark mode appearance
    useEffect(() => {
      const subscription = Appearance.addChangeListener(({ colorScheme }) => {
        setTheme(colorScheme);
      });
      return () => subscription.remove();
    }, []);

    const navigation = useNavigation();
    //Kept for birthday message
    /* 
    const [date, setDate] = React.useState(new Date());
    const [show, setShow] = React.useState(false);
    const [dateSelected, setDateSelected] = React.useState(false);

    console.log(date, show, dateSelected);
    const onChangeCalendar = (event: any, selectedDate: Date | undefined) => {
        console.log('Changing Date');
        const currentDate = selectedDate || date;
        setShow(false);
        setDate(currentDate);
        setDateSelected(true);
        setDateSelected(false);
        console.log('Date change complete');
    };

    const showCalendar = () => {
        setShow(true);
    }; */

    //Useful when we implement the app in french
    /* LocaleConfig.locales['fr'] = {
        monthNames: ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'],
        monthNamesShort: ['Janv.', 'Févr.', 'Mars', 'Avril', 'Mai', 'Juin', 'Juil.', 'Août', 'Sept.', 'Oct.', 'Nov.', 'Déc.'],
        dayNames: ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'],
        dayNamesShort: ['Dim.', 'Lun.', 'Mar.', 'Mer.', 'Jeu.', 'Ven.', 'Sam.'],
        today: 'Aujourd\'hui'
    }; */

    const onSubmit = (newUser: User) => {
        // Register user
        AuthActions.register(newUser)
            .then(() => {
                // Redirect to login page if successful
                navigation.reset({ routes: [{ name: 'Login' }] });
            })
            .catch(() => { navigation.navigate('Register'); }); // Remain on register page if signup fails
    };

    // Validate info entered in the fields
    const validationSchema = yup.object().shape({
        // Required
        firstName: yup
            .string()
            .required('Please provide your first name'),
        // Required
        lastName: yup
            .string()
            .required('Please provide your last name'),
        // Required; Make sure data is in email format
        email: yup
            .string()
            .email('Invalid email')
            .required('Please provide an email'),
        // Required; Password must be between 6-20 characters - numbers, letters, special characters all allowed
        password: yup
            .string()
            .min(6, 'Min. password length required: 6 characters')
            .max(20, 'Max. password length permitted: 20 characters')
            .required('Please enter a password between 6-20 characters'),
        // Passwords must match
        passwordConfirm: yup
            .string()
            .oneOf([yup.ref('password'), null], 'Passwords must match')
            .required('Please confirm your password'),
        // Only digits allowed
        phoneNumber: yup
            .string()
            .min(10, 'Invalid phone number')
            .matches(/[0-9]/, 'Invalid phone number')
    });
    // Initial values are blank or default, updates when user types
    const initialValues = {
        firstName: '',
        lastName: '',
        email: '',
        password: '',
        passwordConfirm: '',
        phoneNumber: '',
        dateOfBirth: '', // Not asked right now but may be required in the future
        gender: 'Undeclared', // Not asked right now but may be required in the future
        avatar: '', // Default avatar, user sets upon login
    };

    return (
        <View style={styles.container}>
            <ScrollView >
                <Formik
                    initialValues={initialValues}
                    validationSchema={validationSchema}
                    onSubmit={(values: User) => onSubmit(values)}
                >
                    {({ values, handleChange, errors, setFieldTouched, touched, handleSubmit }) => (
                        <View style={styles.formContainer}>
                            
                            <Input
                                placeholder='First Name *'
                                onChangeText={handleChange('firstName')}
                                value={values.firstName}
                                errorMessage={touched.firstName && errors.firstName ? errors.firstName : ''}
                                errorStyle={{fontFamily: 'BarlowCondensed_400Regular', fontSize: RFPercentage(2.2)}}
                                leftIcon={<Ionicons name='person' color={theme === 'light' ? 'black': 'white'} style={{fontSize: RFPercentage(1.6)}}/>}
                                onBlur={() => setFieldTouched('firstName')}
                                style={[{color: theme === 'light' ? 'black': 'white'}, styles.input]}
                            />
                            <Input
                                placeholder='Last Name *'
                                onChangeText={handleChange('lastName')}
                                value={values.lastName}
                                errorMessage={touched.lastName && errors.lastName ? errors.lastName : ''}
                                errorStyle={{fontFamily: 'BarlowCondensed_400Regular', fontSize: RFPercentage(2.2)}}
                                onBlur={() => setFieldTouched('lastName')}
                                leftIcon={<Ionicons name='person' color={theme === 'light' ? 'black': 'white'} style={{fontSize: RFPercentage(1.6)}}/>}
                                style={[{color: theme === 'light' ? 'black': 'white'}, styles.input]}
                            />
                            <Input
                                placeholder='Email *'
                                autoCapitalize='none'
                                onChangeText={handleChange('email')}
                                value={values.email}
                                errorMessage={touched.email && errors.email ? errors.email : ''}
                                errorStyle={{fontFamily: 'BarlowCondensed_400Regular', fontSize: RFPercentage(2.2)}}
                                onBlur={() => setFieldTouched('email')}
                                leftIcon={<Ionicons name='mail' color={theme === 'light' ? 'black': 'white'} style={{fontSize: RFPercentage(1.6)}}/>}
                                style={[{color: theme === 'light' ? 'black': 'white'}, styles.input]}
                            />
                            <Input
                                placeholder='Password (6-20 Characters) *'
                                onChangeText={handleChange('password')}
                                value={values.password}
                                errorMessage={touched.password && errors.password ? errors.password : ''}
                                errorStyle={{fontFamily: 'BarlowCondensed_400Regular', fontSize: RFPercentage(2.2)}}
                                passwordRules='minlength: 6'
                                onBlur={() => setFieldTouched('password')}
                                secureTextEntry={true}
                                leftIcon={<Ionicons name='lock-closed' color={theme === 'light' ? 'black': 'white'} style={{fontSize: RFPercentage(1.6)}}/>}
                                style={[{color: theme === 'light' ? 'black': 'white'}, styles.input]}
                            />
                            <Input
                                placeholder='Confirm Password *'
                                onChangeText={handleChange('passwordConfirm')}
                                value={values.passwordConfirm}
                                errorMessage={touched.passwordConfirm && errors.passwordConfirm ? errors.passwordConfirm : ''}
                                errorStyle={{fontFamily: 'BarlowCondensed_400Regular', fontSize: RFPercentage(2.2)}}
                                onBlur={() => setFieldTouched('passwordConfirm')}
                                secureTextEntry={true}
                                leftIcon={<Ionicons name='lock-closed' color={theme === 'light' ? 'black': 'white'} style={{fontSize: RFPercentage(1.6)}}/>}
                                style={[{color: theme === 'light' ? 'black': 'white'}, styles.input]}
                            />
                            <Input
                                placeholder='Phone Number'
                                onChangeText={handleChange('phoneNumber')}
                                value={values.phoneNumber}
                                errorMessage={touched.phoneNumber && errors.phoneNumber ? errors.phoneNumber : ''}
                                errorStyle={{fontFamily: 'BarlowCondensed_400Regular', fontSize: RFPercentage(2.2)}}
                                onBlur={() => setFieldTouched('phoneNumber')}
                                leftIcon={<Ionicons name='phone-portrait' color={theme === 'light' ? 'black': 'white'} style={{fontSize: RFPercentage(1.6)}}/>}
                                style={[{color: theme === 'light' ? 'black': 'white'}, styles.input]}
                            />
                            
                            <TouchableOpacity style={styles.signupContainer} onPress={() => { handleSubmit() }}>
                                <Text style={styles.buttonSignup}>Sign Up</Text>
                            </TouchableOpacity>

                            {/* Display error message if any */}

                            {/* {props.errors.user !== undefined ?
                                <Text style={styles.error} >{props.errors['user']}</Text>
                                : <Text style={styles.error} ></Text>} */}
                        </View>
                    )}
                </Formik>
            </ScrollView>
        </View>
    );


};

export default connect(mapStateToProps)(Register);
