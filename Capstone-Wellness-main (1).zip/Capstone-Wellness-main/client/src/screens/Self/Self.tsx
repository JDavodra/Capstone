import * as React from 'react';
import { Alert, Image, Linking, Dimensions } from 'react-native';

import { Button as ButtonElem, ScrollView, TouchableOpacity, SafeAreaView } from 'react-native';

import { useNavigation } from '@react-navigation/native';

import { Text, View } from '../../components/Themed';
import styles from './styles';

import CoolIcons from '../../../CoolIcons';
import Colors from '../../constants/Colors';

import Journal from '../Journal';
import { Card } from 'react-native-elements';
import { List } from 'react-native-paper';
import { useEffect, useState } from 'react';
import darkModeStyles from './darkModeStyles';
import { Appearance } from 'react-native-appearance';
import { RFPercentage } from 'react-native-responsive-fontsize';

export default function Self() {

  const [theme, setTheme] = useState(Appearance.getColorScheme());
  
  // handles light/dark mode appearance
  useEffect(() => {
    const subscription = Appearance.addChangeListener(({ colorScheme }) => {
      setTheme(colorScheme);
    });
    return () => subscription.remove();
  }, []);
  
  const navigation = useNavigation();
  const [expanded, setExpanded] = React.useState(false);

  //phone numbers 
  const ont = 18669255454;
  const can = 18336285589;
  const int = 12159428478;
  const pro = 16135625411;

  //boolean value to expand the accordion list on touch of the user
  const handlePress = () => setExpanded(!expanded);

  let dim = Dimensions.get('window').width*0.21

  return (
      <SafeAreaView style={theme === 'light' ? styles.container : darkModeStyles.container}>
        <ScrollView contentContainerStyle={styles.scrollContainer}>
          <Text style={styles.title}>Self-Help</Text>
          <Card containerStyle={[styles.cardEmerg, {borderColor: theme === 'light' ? '#f4f4f4' : 'grey'} ]}>
          <List.Accordion
            title="Emergency Contacts"
            expanded={expanded}
            onPress={handlePress}
            theme={{ colors: { background: Colors.blueSecondary } }}
            titleStyle={styles.titleEcall}>
            <List.Item onPress={() => Linking.openURL(`tel:${ont}`)} title="Ontario - Good2Talk" titleStyle={styles.callText} left={props => <View style={styles.ddIcon}><CoolIcons name="phone" color={"black"} style={{fontSize: RFPercentage(2.5)}}/></View>} />
            <List.Item onPress={() => Linking.openURL(`tel:${can}`)} title="Canada - EmpowerMe" titleStyle={styles.callText} left={props => <View style={styles.ddIcon}><CoolIcons name="phone" color={"black"} style={{fontSize: RFPercentage(2.5)}}/></View>} />
            <List.Item onPress={() => Linking.openURL(`tel:${int}`)} title="Outside Canada - International SOS" titleStyle={styles.callText} left={props => <View style={styles.ddIcon}><CoolIcons name="phone" color={"black"} style={{fontSize: RFPercentage(2.5)}}/></View>} />
            <List.Item onPress={() => Linking.openURL(`tel:${pro}`)} title="Protection Emergency" titleStyle={styles.callText} left={props => <View style={styles.ddIcon}><CoolIcons name="phone" color={"black"} style={{fontSize: RFPercentage(2.5)}}/></View>} />
          </List.Accordion>
          </Card>
          {/* Navigate to journal screen */}
          <TouchableOpacity style= { styles.touchable } onPress={() => navigation.navigate('Journal')} activeOpacity={0.5}>
            <View style= {theme === 'light' ? styles.element : darkModeStyles.element}>
              <View style= {theme === 'light' ? styles.imageContainer : darkModeStyles.imageContainer}> 
                <Image style={[styles.imageStyle, {height: dim, width: dim}]} source = {require('../../../assets/images/illustration_3.png')} resizeMethod="scale" resizeMode='contain'/>
              </View>
              <View style={theme === 'light' ? styles.contentContainer : darkModeStyles.contentContainer}>
                <Text style={ styles.titleElem}>My Journal</Text>
                <Text style={ styles.featureDesc}>Write down your thoughts as they pop up, your  emotions, ... </Text>
              </View>
              <View style={theme === 'light' ? styles.iconContainer : darkModeStyles.iconContainer}><CoolIcons name="chevron_big_right" style={{fontSize: RFPercentage(3.8)}} color={Colors.bluePrimary} /></View>
            </View>
          </TouchableOpacity>
          {/* Coming soon message */}
          {/* <TouchableOpacity onPress={() => {Alert.alert("Coming Soon!")}} activeOpacity={0.5}>
            <View style= {theme === 'light' ? styles.element : darkModeStyles.element}>
              <View style= {theme === 'light' ? styles.imageContainer : darkModeStyles.imageContainer}> 
                <Image style={[styles.imageStyle, {height: dim, width: dim}]} source = {require('../../../assets/images/illustration_2.png')} resizeMethod="scale" resizeMode='contain' />
              </View>
              <View style={theme === 'light' ? styles.contentContainer : darkModeStyles.contentContainer}>
                <Text style={ styles.titleElem}>Wellness Journey</Text>
                <Text style={ styles.featureDesc}>Learn about wellness and how to manage your mental health.</Text>
              </View>
              <View style={theme === 'light' ? styles.iconContainer : darkModeStyles.iconContainer}><CoolIcons name="chevron_big_right" style={{fontSize: RFPercentage(3.8)}} color={Colors.bluePrimary} /></View>
            </View>
          </TouchableOpacity>   */}
          <TouchableOpacity onPress={() => {navigation.navigate("BookSession")}} activeOpacity={0.5}>
            <View style= {theme === 'light' ? styles.element : darkModeStyles.element}>
              <View style= {theme === 'light' ? styles.imageContainer : darkModeStyles.imageContainer}> 
                <Image style={[styles.imageStyle, {height: dim, width: dim}]} source = {require('../../../assets/images/wellnessCharacter/talk-counsellor-circe.jpg')} />
              </View>
              <View style={theme === 'light' ? styles.contentContainer : darkModeStyles.contentContainer}>
                <Text style={styles.titleElem}>Mental Health Support</Text>
                <Text style={ styles.featureDesc}>Book a session to talk to a counsellor or a mental health specialist.</Text>
              </View>
              <View style={theme === 'light' ? styles.iconContainer : darkModeStyles.iconContainer}><CoolIcons name="chevron_big_right" style={{fontSize: RFPercentage(3.8)}} color={Colors.bluePrimary} /></View>
            </View>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => Linking.openURL('https://www2.uottawa.ca/campus-life/health-wellness/student-health-wellness-centre')} activeOpacity={0.5}>
            <View style= {theme === 'light' ? styles.element : darkModeStyles.element}>
              <View style= {theme === 'light' ? styles.imageContainer : darkModeStyles.imageContainer}> 
                <Image style={[styles.imageStyle, {height: dim, width: dim}]} source = {require('../../../assets/images/illustration_4.png')} />
              </View>
              <View style={theme === 'light' ? styles.contentContainer : darkModeStyles.contentContainer}>
                <Text style={styles.titleElem}>Need to see a doctor ?</Text>
                <Text style={ styles.featureDesc}>Book an appoitment with Student Health and Wellness Center on campus.</Text>
              </View>
              <View style={theme === 'light' ? styles.iconContainer : darkModeStyles.iconContainer}><CoolIcons name="chevron_big_right" style={{fontSize: RFPercentage(3.8)}} color={Colors.bluePrimary} /></View>
            </View>
          </TouchableOpacity>
        </ScrollView>
      </SafeAreaView>
  );
}
