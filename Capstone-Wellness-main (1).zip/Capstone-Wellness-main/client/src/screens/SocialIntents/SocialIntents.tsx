import React, { Component, useState } from 'react';
import { View, Text } from 'react-native';
import { Appearance } from 'react-native-appearance';
import { DotIndicator } from 'react-native-indicators';
import { SafeAreaView } from 'react-native-safe-area-context';


import { WebView } from 'react-native-webview';
import styles from '../Home/styles';
import darkModeStyles from '../Home/darkModeStyles';

export default function Socialintents() {
    //INFO : url for the social intent live chat provided by uOttawa Health promotion 
  
    //retriveing the theme
    const [theme,setTheme] =  useState(Appearance.getColorScheme())


    const ActivityIndicatorElement = () => {
      return (
        <DotIndicator size={10} color='#EA7754'/>
      );
    };
    return (
      
      <View style={theme === 'light' ? styles.container : darkModeStyles.container}>
        <WebView 
        style={theme === 'light' ? styles.container : darkModeStyles.container}  
        renderLoading={ActivityIndicatorElement}
        startInLoadingState={true}
        source={{ uri: 'https://www.socialintents.com/chatWidget.1.0.jsp?s=undefined&wid=2c9faa357418a9da0174300a5a3b1f09&hp=false&t=1602957044246&uid=1599574196171&v=3&cp=null&p=https%3A//www.uottawa.ca/wellness/lounge&r=https%3A//www.uottawa.ca/wellness/students/peer-experts-and-mentors#' }} 
      />

      </View>

    );
}
  