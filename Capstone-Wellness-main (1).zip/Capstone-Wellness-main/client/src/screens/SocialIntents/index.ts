import SocialIntents from  './SocialIntents';

export default SocialIntents;
