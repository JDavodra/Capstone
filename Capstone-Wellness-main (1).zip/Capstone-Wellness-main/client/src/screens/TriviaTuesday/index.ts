import TriviaTuesday from './TriviaTuesday';
export default TriviaTuesday;
