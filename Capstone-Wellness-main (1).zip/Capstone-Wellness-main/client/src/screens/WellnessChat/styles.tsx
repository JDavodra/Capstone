// import { StyleSheet } from "react-native";

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     alignItems: 'stretch',
//     paddingHorizontal: '2%',
//   },
//   formContainer: {
//     paddingVertical: '20%',
//     paddingHorizontal: '5%',
//     flex: 1,
//     alignContent: 'flex-start',
//     justifyContent: 'center',
//     alignSelf: 'stretch'
//   },
//   scrollContainer: {
//     paddingBottom: '5%',
//   },
//   input: {
//     color: 'black',
//     backgroundColor: 'white',
//     marginVertical: '4%',
//     height: 50,
//     fontFamily: 'arial',
//     borderBottomColor: 'grey',
//     borderBottomWidth: 1,
//     borderTopRightRadius: 16,
//     borderTopLeftRadius: 16
//   },
//   inputText: {
//     fontWeight: 'normal',
//     fontStyle: 'normal',
//     color: 'black'
//   },
//   dropdown: {
//     color: 'grey',
//     backgroundColor: 'white',
//     marginVertical: '4%',
//     height: 55,
//     justifyContent: 'flex-start',
//     borderTopRightRadius: 16,
//     borderTopLeftRadius: 16
//   },
//   dropdownText: {
//     justifyContent: 'flex-end',
//     textAlignVertical: 'bottom',
//     paddingVertical: '1%'
//   },
//   submit: {
//     alignContent: 'center',
//     alignItems: 'center',
//     justifyContent: 'center',
//     color: 'white',
//     borderRadius: 16,
//     marginVertical: '2%'
//   }
// });

// export default styles;
