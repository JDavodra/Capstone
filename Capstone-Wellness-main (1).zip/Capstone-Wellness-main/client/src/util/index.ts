import AuthUtils from './AuthUtils';

const util = { AuthUtils };

export default util;
